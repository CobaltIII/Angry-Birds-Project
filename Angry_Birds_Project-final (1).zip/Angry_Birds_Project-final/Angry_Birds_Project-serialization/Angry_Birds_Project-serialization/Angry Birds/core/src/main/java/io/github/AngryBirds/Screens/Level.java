package io.github.AngryBirds.Screens;

import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.physics.box2d.joints.DistanceJoint;
import com.badlogic.gdx.physics.box2d.joints.DistanceJointDef;
import com.badlogic.gdx.physics.box2d.joints.MouseJoint;
import com.badlogic.gdx.physics.box2d.joints.MouseJointDef;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import io.github.AngryBirds.Angry_Birds;
import io.github.AngryBirds.game_bodies.Birds.Bird;
import io.github.AngryBirds.game_bodies.Targets.*;
import io.github.AngryBirds.game_bodies.game_body;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;

public class Level extends InputAdapter implements Serializable, Screen {
    protected Serialize save;
    protected World world;
    protected Box2DDebugRenderer DRend;
    protected OrthographicCamera camera;
    protected Viewport viewport;
    protected MouseJoint mjoint;
    protected DistanceJoint djoint;
    protected SpriteBatch batch;
    protected String folderpath;

    private final Vector3 mousepos = new Vector3();
    private final Vector2 mousepos2d = new Vector2();
    protected final ArrayList<Bird> birds = new ArrayList<>();
    protected final ArrayList<game_body> all_objects = new ArrayList<>();
    protected final ArrayList<Targets> targets = new ArrayList<>();

    public static final float pixel_to_meters = 5;
    protected boolean win;
    protected boolean ended;
    protected boolean paused;
    protected final float gravity = -9.81f*6;

    private final Texture three_starsTexture = new Texture("level/3stars-2.png");
    private final Texture two_starsTexture = new Texture("level/2stars-1.png");
    private final Texture one_starTexture = new Texture("level/1star-1.png");
    private final Texture lose_screenTexture = new Texture("level/lose-2.png");
    private final Texture menuTexture = new Texture("level/nmenu.png");
    private final Texture nextTexture = new Texture("level/next.png");
    private final Texture backgroundTexture = new Texture("level/background2.png");
    private final Texture groundTexture = new Texture("level/ground2.png");
    private final Texture catapultTexture = new Texture("level/Catapult-3.png");
    private final Texture pauseTexture = new Texture("level/npause.png");
    private final Texture resumeTexture = new Texture("level/nresume.png");
    private final Texture retryTexture = new Texture("level/nnretry.png");

    private Sprite background;
    private Sprite catapult;
    private Sprite resume;
    private Sprite retry;
    private Sprite menu;
    private Sprite ground;
    private Sprite pause;
    private Sprite three_Stars;
    private Sprite two_Stars;
    private Sprite one_Star;
    private Sprite lose_screen;
    private Sprite next;
    private Sprite end_screen;

    private Body catapultBody;

    //setting up sprites
    protected void create_level() {
        save = Serialize.getInstance();
        DRend = new Box2DDebugRenderer();
        camera = new OrthographicCamera((float) Gdx.graphics.getWidth(), (float) Gdx.graphics.getHeight());
        viewport = new FitViewport(Gdx.graphics.getWidth()/pixel_to_meters, Gdx.graphics.getHeight()/pixel_to_meters, camera);
        world = new World(new Vector2(0, gravity), true);
        save.getWorld(world);
        resume = new Sprite(resumeTexture);
        retry = new Sprite(retryTexture);
        menu = new Sprite(menuTexture);
        background = new Sprite(backgroundTexture);
        ground = new Sprite(groundTexture);
        catapult = new Sprite(catapultTexture);
        pause = new Sprite(pauseTexture);
        three_Stars = new Sprite(three_starsTexture);
        two_Stars = new Sprite(two_starsTexture);
        one_Star = new Sprite(one_starTexture);
        lose_screen = new Sprite(lose_screenTexture);
        next = new Sprite(nextTexture);
    }

    protected void setsize(){
        background.setSize(background.getWidth(),background.getHeight());
        pause.setSize(pauseTexture.getWidth(), pauseTexture.getHeight());
        ground.setSize(ground.getWidth(), ground.getHeight());
        catapult.setSize((float) catapultTexture.getWidth() /8, (float) catapultTexture.getHeight() /8);
        menu.setSize(menuTexture.getWidth(), menuTexture.getHeight());
        retry.setSize(retryTexture.getWidth(), retryTexture.getHeight());
        resume.setSize(resumeTexture.getWidth(), resumeTexture.getHeight());
        three_Stars.setSize(three_starsTexture.getWidth(), three_starsTexture.getHeight());
        two_Stars.setSize(two_starsTexture.getWidth(), two_starsTexture.getHeight());
        one_Star.setSize(one_starTexture.getWidth(), one_starTexture.getHeight());
        lose_screen.setSize(lose_screenTexture.getWidth(), lose_screenTexture  .getHeight());
        next.setSize(nextTexture.getWidth(), nextTexture.getHeight());
        System.out.println(Gdx.graphics.getWidth()+" "+Gdx.graphics.getHeight());
    }

    protected void setposition() {
        pause.setPosition(0, Gdx.graphics.getHeight() - pause.getHeight());
        background.setPosition(0, (float) Gdx.graphics.getHeight() / 4);
        ground.setPosition(0,background.getY()-ground.getHeight()*0.94f);
        create_ground();
        catapult.setPosition((float) Gdx.graphics.getWidth() / 7, background.getY());
        create_catapult_body();
        resume.setPosition(0, Gdx.graphics.getHeight() - resume.getHeight()+2);
        retry.setPosition(resumeTexture.getWidth(),Gdx.graphics.getHeight() - retry.getHeight());
        menu.setPosition(retryTexture.getWidth()+retry.getX(),Gdx.graphics.getHeight() - menu.getHeight());
    }

    protected void set_button_position() {
        pause.setPosition(0, Gdx.graphics.getHeight() - pause.getHeight());
        resume.setPosition(0, Gdx.graphics.getHeight() - resume.getHeight()+2);
        retry.setPosition(resumeTexture.getWidth(),Gdx.graphics.getHeight() - retry.getHeight());
        menu.setPosition(retryTexture.getWidth()+retry.getX(),Gdx.graphics.getHeight() - menu.getHeight());
    }

    protected void set_target_position() {
        for (Targets target : targets) {
            float offset_y = target.getSprite().getHeight()/2;
            float offset_x = target.getSprite().getWidth()/2;
            target.getBody().setTransform((offset_x+target.getSprite().getX())/pixel_to_meters,(offset_y+target.getSprite().getY())/pixel_to_meters,target.getSprite().getRotation()* MathUtils.degreesToRadians);
        }
    }

    protected void set_bird_position(){
        Bird bird;
        if (!birds.isEmpty()) {
            bird = birds.get(0);
            bird.set_collided(false);
            bird.getBody().setTransform((catapult.getX() + bird.getSprite().getWidth()/2)/pixel_to_meters, (background.getY() + catapult.getHeight()*0.8f)/pixel_to_meters, 0);
            create_distance_joint(bird.getBody());
        }
        if (birds.size()>1){
            for (int i = 1; i < birds.size(); i++){
                bird = birds.get(i);
                Bird previous =  birds.get(i-1);
                bird.getBody().setAwake(true);
                bird.getBody().setActive(true);
                float new_x = previous.getBody().getPosition().x-(previous.getBody().getFixtureList().get(0).getShape().getRadius()+bird.getBody().getFixtureList().get(0).getShape().getRadius());
                bird.getBody().setTransform(new_x, background.getY()/pixel_to_meters, 0);
            }
        }
    }

    //add functions
    public void add_bird(Bird bird){
        birds.add(1,bird);
        all_objects.add(bird);
    }

    public void add_target(Targets target){
        targets.add(target);
    }

    // draw functions
    protected void draw_background() {
        background.draw(batch);
        catapult.draw(batch);
        ground.draw(batch);
    }

    protected void draw_tint(){
        //drawing a tint
        ShapeRenderer shapeRenderer = new ShapeRenderer();
        Gdx.gl.glEnable(GL20.GL_BLEND);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        shapeRenderer.setColor(0f,0f,0f,0.6f);
        shapeRenderer.rect(0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        shapeRenderer.end();
        Gdx.gl.glDisable(GL20.GL_BLEND);
    }

    protected void draw_paused(){
        draw_game();
        draw_tint();
        batch.begin();
        menu.draw(batch);
        retry.draw(batch);
        resume.draw(batch);
        batch.end();
    }

    protected void draw_game(){
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        batch.begin();
        draw_background();
        pause.draw(batch);
        for (game_body b : all_objects){
            b.setposition(pixel_to_meters);
            b.getSprite().draw(batch);
        }
        batch.end();
    }

    protected void draw_end(boolean win,int points, int max_points){
        draw_game();
        draw_tint();
        batch.begin();
        end_screen.draw(batch);
        retry.draw(batch);
        next.draw(batch);
        menu.draw(batch);
        batch.end();
    }

    // creating game elements

    private void create_ground(){
        ChainShape chain = new ChainShape();
        chain.createChain(new Vector2[]{new Vector2(-Gdx.graphics.getWidth(), 0), new Vector2(Gdx.graphics.getWidth(), 0)});

        BodyDef ground_def = new BodyDef();
        ground_def.type = BodyDef.BodyType.StaticBody;
        ground_def.position.set(ground.getX()/pixel_to_meters,background.getY()/pixel_to_meters);

        FixtureDef fixd = new FixtureDef();
        fixd.shape = chain;
        fixd.friction = 0.8f;
        fixd.restitution = 0.0f;
        Body ground_body = world.createBody(ground_def);
        ground_body.createFixture(fixd);
        chain.dispose();
    }

    private void create_catapult_body(){
        BodyDef point = new BodyDef();
        point.type = BodyDef.BodyType.StaticBody;
        point.position.set((catapult.getX()+catapult.getWidth()/2)/pixel_to_meters, (catapult.getY()+catapult.getHeight()*0.8f)/pixel_to_meters);

        CircleShape circle = new CircleShape();
        circle.setRadius(5f/pixel_to_meters);

        FixtureDef fd = new FixtureDef();
        fd.shape = circle;
        fd.filter.groupIndex = -1;
        fd.density = 0;

        catapultBody = world.createBody(point);
        catapultBody.createFixture(fd);
        circle.dispose();
    }

    protected void create_distance_joint(Body body){
        DistanceJointDef joint_def = new DistanceJointDef();
        joint_def.bodyA = catapultBody;
        joint_def.bodyB = body;
        joint_def.dampingRatio = 1f;
        joint_def.length = 0;
        joint_def.frequencyHz = 1;
        djoint = (DistanceJoint) world.createJoint(joint_def);
    }

    protected void create_bodies(){
        for (game_body g : all_objects){
            g.create_body(world, pixel_to_meters);
        }
    }

    protected void create(){
        batch = new SpriteBatch();
        Gdx.input.setInputProcessor(this);
        create_level();
        setsize();
        setposition();
    }

    // inputs
    /*
    protected void game_inputs(){
        Bird bird;
        if (!birds.isEmpty()){
            bird = birds.get(0);
            if (Gdx.input.isTouched()){
                Vector3 mousePos = new Vector3(Gdx.input.getX(), Gdx.input.getY(), 0);
                float angle = new Vector2(mousePos.x, mousePos.y).sub(bird.getBody().getPosition()).angleRad();
                if (mjoint == null && Angry_Birds.check(bird.getSprite())){
                    create_mouse_joint(bird.getBody());
                }
                else if (mjoint != null){
                    camera.unproject(mousePos);
                    mjoint.setTarget(new Vector2(Gdx.input.getX(), Gdx.input.getY()));
                }
            }
            else if (mjoint != null && !Gdx.input.isButtonJustPressed(Input.Buttons.LEFT)){
                world.destroyJoint(mjoint);
                mjoint = null;
            }
        }
    }
*/
    protected void end_inputs(){
        if (Gdx.input.isButtonJustPressed(Input.Buttons.LEFT)){
            if (Angry_Birds.check(next)){
                System.out.println("hi");
                int level = 1;
                try {
                    System.out.println("hi");
                    level = Integer.parseInt(String.valueOf(folderpath.charAt(folderpath.length()-2)));
                    level++;
                    if (level>3){
                        throw new RuntimeException();
                    }
                }
                catch (Exception e){
                    dispose();
                    Angry_Birds.getInstance().setScreen(new Level_Selector());
                    return;
                }
                dispose();
                Angry_Birds.getInstance().setScreen(new Level_Screen(folderpath.substring(0,folderpath.length()-2)+level+"/"));
            }
            else if(Angry_Birds.check(retry)){
                dispose();
                Angry_Birds.getInstance().setScreen(new Level_Screen(folderpath));
            }
            else if(Angry_Birds.check(menu)){
                Angry_Birds.getInstance().setScreen(new Level_Selector());
            }
        }
    }

    protected void pause_inputs() throws IOException {
        if (Gdx.input.isButtonJustPressed(Input.Buttons.LEFT)) {
            if (Angry_Birds.check(resume)) {
                paused = false;
            }
            else if (Angry_Birds.check(retry)) {
                dispose();
                Angry_Birds.getInstance().setScreen(new Level_Screen(folderpath));
            }
            else if (Angry_Birds.check(menu)) {
                if (!folderpath.contains("_s/")){
                    folderpath = folderpath.substring(0,folderpath.length()-1)+"_s/";
                }
                new PrintWriter(folderpath+"Birds.txt").close();
                new PrintWriter(folderpath+"Pigs.txt").close();
                new PrintWriter(folderpath+"Wood.txt").close();
                new PrintWriter(folderpath+"Glass.txt").close();
                new PrintWriter(folderpath+"Stone.txt").close();
                new PrintWriter(folderpath+"Wood.txt").close();

                for (Bird i : birds){
                    i.savable_save(i,folderpath);
                }

                for(Targets i : targets){
                    i.savable_save(pixel_to_meters,folderpath);
                }
                dispose();
                Angry_Birds.getInstance().setScreen(new Level_Selector());
            }
        }
    }

    protected void normal_inputs(){
        if (Gdx.input.isButtonJustPressed(Input.Buttons.LEFT)) {
            if (Angry_Birds.check(pause)){
                paused = true;
                System.out.println("hi");
            }
        }
    }

    protected void create_mouse_joint(Body body){
        MouseJointDef mjoint_def = new MouseJointDef();
        mjoint_def.bodyA = catapultBody;
        mjoint_def.bodyB = body;
        mjoint_def.target.set(body.getPosition().x,body.getPosition().y);
        mjoint_def.collideConnected = true;
        mjoint_def.maxForce = 2000;
        mjoint = (MouseJoint) world.createJoint(mjoint_def);
    }

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        camera.unproject(mousepos.set(screenX,screenY,0));
        if (birds.isEmpty()){
            return false;
        }
        if (Angry_Birds.check(birds.get(0).getSprite()) && !birds.get(0).get_launched()){
            create_mouse_joint(birds.get(0).getBody());
        }
        if (birds.get(0).get_launched() && !birds.get(0).get_collided()){
            birds.get(0).activateAbility(this);
            birds.get(0).set_collided(true);
        }
        return true;
    }

    public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        if (mjoint == null || birds.isEmpty()){
            return false;
        }
        launch();
        return true;
    }

    public boolean touchDragged(int screenX, int screenY, int pointer) {
        if (mjoint == null){
            return false;
        }
        camera.unproject(mousepos.set(screenX, screenY, 0));
        mjoint.setTarget(mousepos2d.set(mousepos.x,mousepos.y));
        return true;
    }

    private void launch(){
        Body bird = birds.get(0).getBody();
        world.destroyJoint(mjoint);
        world.destroyJoint(djoint);
        mjoint = null;
        Vector2 launch = new Vector2((catapultBody.getPosition().x-bird.getPosition().x)*(50),(catapultBody.getPosition().y-bird.getPosition().y)*(50));
        bird.setLinearVelocity(launch);
        ((Bird)(bird.getUserData())).set_launched();
        System.out.println(bird.getLinearVelocity()+" "+catapult.getX()+" "+bird.getPosition().x+" "+catapult.getY()+" "+bird.getPosition().y);
    }

    //screen
    @Override
    public void show() {
        create();
    }

    @Override
    public void render(float v) {

    }

    @Override
    public void resize(int i, int i1) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        backgroundTexture.dispose();
        catapultTexture.dispose();
        groundTexture.dispose();
        pauseTexture.dispose();
        retryTexture.dispose();
        resumeTexture.dispose();
        menuTexture.dispose();
        two_starsTexture.dispose();
        one_starTexture.dispose();
        three_starsTexture.dispose();
        lose_screenTexture.dispose();
        world.dispose();
        batch.dispose();
        DRend.dispose();
        all_objects.clear();
        birds.clear();
        targets.clear();
    }

    protected void set_end(boolean win,int points,int max_points){
        three_Stars.setPosition((float) Gdx.graphics.getWidth() /2-three_Stars.getWidth()/2, 0);
        two_Stars.setPosition((float) Gdx.graphics.getWidth() /2-two_Stars.getWidth()/2, 0);
        one_Star.setPosition((float) Gdx.graphics.getWidth() /2-one_Star.getWidth()/2, 0);
        lose_screen.setPosition((float) Gdx.graphics.getWidth() /2-lose_screen.getWidth()/2, 0);
        if (win){
            if (points>max_points*0.66f){
                end_screen = three_Stars;
            }
            else if(points>max_points*0.33f){
                end_screen = two_Stars;
            }
            else{
                end_screen = one_Star;
            }
        }
        else{
            end_screen = lose_screen;
        }
        if (win){
            retry.setPosition(three_Stars.getX() + three_Stars.getX() / 2, Gdx.graphics.getHeight() / 4.5f);
            menu.setPosition(three_Stars.getX() + three_Stars.getX() / 10, Gdx.graphics.getHeight() / 4.5f);
            next.setPosition(three_Stars.getX() * 1.9f, Gdx.graphics.getHeight() / 4.5f + 5);
        }
        else {
            retry.setPosition(three_Stars.getX() + three_Stars.getX()*3/4, Gdx.graphics.getHeight() / 4.5f);
            menu.setPosition(three_Stars.getX() + three_Stars.getX()/4 , Gdx.graphics.getHeight() / 4.5f);
            next.setPosition(Gdx.graphics.getWidth()+next.getWidth(),Gdx.graphics.getHeight()+next.getHeight());
        }
    }
}
