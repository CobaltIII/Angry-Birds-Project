package io.github.AngryBirds.Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.MathUtils;
import io.github.AngryBirds.Angry_Birds;
import io.github.AngryBirds.game_bodies.Birds.Bird;
import io.github.AngryBirds.game_bodies.Birds.Blue_Bird;
import io.github.AngryBirds.game_bodies.Birds.Red_Bird;
import io.github.AngryBirds.game_bodies.Birds.Yellow_Bird;
import io.github.AngryBirds.game_bodies.Targets.*;
import io.github.AngryBirds.game_bodies.game_body;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class Level_maker extends Level {
    private final ArrayList<game_body> displaySprites_birds = new ArrayList<>();
    private final ArrayList<game_body> displaySprites_targets = new ArrayList<>();
    private int currentSprite = 0;
    private ArrayList<game_body> current_sprites = displaySprites_targets;
    private Sprite instruction;
    private Texture instruction_texture;
    private final String custom_level = "../core/src/main/java/io/github/AngryBirds/Levels/Custom_level/";

    private void addDisplaySprite() {
        displaySprites_birds.add(new Red_Bird());
        displaySprites_birds.add(new Blue_Bird());
        displaySprites_birds.add(new Yellow_Bird());
        displaySprites_targets.add(new Glass());
        displaySprites_targets.add(new Stone());
        displaySprites_targets.add(new Wood());
        displaySprites_targets.add(new Pigs());
        for (game_body b : displaySprites_targets) {
            b.getSprite().setPosition(50, 0);
        }
        for (game_body b : displaySprites_birds) {
            b.getSprite().setPosition(50, 0);
        }
    }

    @Override
    public void show() {
        super.show();
        Gdx.input.setInputProcessor(this);
        instruction_texture = new Texture("level/instruction.png");
        instruction = new Sprite(instruction_texture);
        instruction.setPosition(0,300);
        addDisplaySprite();
        create_bodies();
    }

    @Override
    public void render(float v) {
        world.step(1/60f, 8,3);
        draw_game();
        batch.begin();
        current_sprites.get(currentSprite).getSprite().draw(batch);
        instruction.draw(batch);
        batch.end();
        DRend.render(world,camera.combined);
        try {
            inputs();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
        set_button_position();
        batch = new SpriteBatch();
        set_bird_position();
        set_target_position();
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        super.dispose();
    }

    private void inputs() throws IOException {
        if (Gdx.input.isButtonJustPressed(Input.Buttons.RIGHT)) {
            currentSprite++;
            if (currentSprite >= current_sprites.size()){
                currentSprite = 0;
            }
        }
        if (Gdx.input.isKeyJustPressed(Input.Keys.ENTER)){
            if (current_sprites == displaySprites_targets){
                current_sprites = displaySprites_birds;
            }
            else {
                current_sprites = displaySprites_targets;
            }
            currentSprite = 0;
        }
        if (Gdx.input.isKeyJustPressed(Input.Keys.D) && current_sprites == displaySprites_targets){
            if (!(displaySprites_targets.get(currentSprite)  instanceof Pigs)){
                int rotation = displaySprites_targets.get(currentSprite).getSprite().getRotation() == 0 ? 90:0;
                displaySprites_targets.get(currentSprite).getSprite().setRotation(rotation);
            }
        }
        if (Gdx.input.isButtonJustPressed(Input.Buttons.LEFT)){
            if (current_sprites == displaySprites_birds){
                switch (currentSprite){
                    case 0: {
                        birds.add(new Red_Bird());
                        break;
                    }
                    case 1:{
                        birds.add(new Blue_Bird());
                        break;
                    }
                    case 2: {
                        birds.add(new Yellow_Bird());
                        break;
                    }
                }
                all_objects.add(birds.get(birds.size()-1));
            }
            else if (current_sprites == displaySprites_targets){
                switch (currentSprite){
                    case 0: {
                        targets.add(new Glass());
                        break;
                    }
                    case 1:{
                        targets.add(new Stone());
                        break;
                    }
                    case 2: {
                        targets.add(new Wood());
                        break;
                    }
                    case 3: {
                        targets.add(new Pigs());
                        break;
                    }
                }
                all_objects.add(targets.get(targets.size()-1));
            }
            all_objects.get(all_objects.size()-1).create_body(world,pixel_to_meters);
            all_objects.get(all_objects.size()-1).getBody().setTransform(Gdx.input.getX()/pixel_to_meters, (Gdx.graphics.getHeight()-Gdx.input.getY())/pixel_to_meters, current_sprites.get(currentSprite).getSprite().getRotation()*MathUtils.degreesToRadians);
            set_bird_position();

        }
        if (Gdx.input.isKeyJustPressed(Input.Keys.E)){
            if (!all_objects.isEmpty()) {
                game_body remove = all_objects.get(all_objects.size() - 1);
                if (remove instanceof Bird){
                    birds.remove(remove);
                }
                else if (remove instanceof Targets){
                    targets.remove(remove);
                }
                world.destroyBody(remove.getBody());
                all_objects.remove(all_objects.size() - 1);
            }
        }
        if (Gdx.input.isKeyJustPressed(Input.Keys.R)){
            for (game_body b : all_objects){
                world.destroyBody(b.getBody());
            }
            all_objects.clear();
            targets.clear();
            birds.clear();
        }
        if (Gdx.input.isKeyJustPressed(Input.Keys.F)){
            new PrintWriter(custom_level+"Birds.txt").close();
            new PrintWriter(custom_level+"Pigs.txt").close();
            new PrintWriter(custom_level+"Wood.txt").close();
            new PrintWriter(custom_level+"Glass.txt").close();
            new PrintWriter(custom_level+"Stone.txt").close();
            new PrintWriter(custom_level+"Wood.txt").close();

            for (Bird i : birds){
                i.savable_save(i,custom_level);
            }

            for(Targets i : targets){
                i.savable_save(pixel_to_meters,custom_level);
            }
            Angry_Birds.getInstance().setScreen(new Level_Screen(custom_level));
        }
        if (Gdx.input.isKeyJustPressed(Input.Keys.M)){
            all_objects.clear();
            targets.clear();
            birds.clear();

            ArrayList<Bird> Birdie_list = save.BirdGetter(custom_level);
            birds.addAll(Birdie_list);

            ArrayList<Pigs> Piggie_list = save.PigGetter(custom_level);
            targets.addAll(Piggie_list);

            ArrayList<Targets> Targets_list = save.StructureGetter(custom_level);
            targets.addAll(Targets_list);

            all_objects.addAll(targets);
            all_objects.addAll(birds);

            System.out.println(birds.size() + "  " +  targets.size() + "   " + all_objects.size());

            Angry_Birds.getInstance().setScreen(new Level_Screen(custom_level));
        }
    }

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        return true;
    }

    @Override
    public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        return true;
    }

    @Override
    public boolean touchDragged(int screenX, int screenY, int pointer) {
        return true;
    }

}
