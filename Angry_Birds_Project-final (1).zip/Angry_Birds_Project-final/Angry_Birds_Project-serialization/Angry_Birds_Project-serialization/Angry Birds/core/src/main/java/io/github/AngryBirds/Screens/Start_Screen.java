package io.github.AngryBirds.Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import io.github.AngryBirds.Angry_Birds;

public class Start_Screen implements Screen {
    private SpriteBatch batch;
    private Sprite background;


    @Override
    public void show() {
        batch = new SpriteBatch();
        Texture backgroundTexture = new Texture("menu_screens/StartScreen.png");
        background = new Sprite(backgroundTexture);
        background.setSize(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
    }

    @Override
    public void render(float v) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        batch.begin();
        background.draw(batch);
        batch.end();
        input();
    }

    @Override
    public void resize(int i, int i1) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        batch.dispose();
    }

    private void input(){
        if (Gdx.input.isButtonJustPressed(Input.Buttons.LEFT)){
            Angry_Birds.getInstance().setScreen(new Level_Selector());
        }
        if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)){
            Angry_Birds.getInstance().setScreen(new Level_maker());
        }
        if (Gdx.input.isKeyJustPressed(Input.Keys.ENTER)){
            Angry_Birds.getInstance().setScreen(new Level_maker());
        }
    }
}
