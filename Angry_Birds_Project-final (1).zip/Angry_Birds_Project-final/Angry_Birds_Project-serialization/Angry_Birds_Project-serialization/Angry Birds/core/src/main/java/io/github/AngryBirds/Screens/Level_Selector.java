package io.github.AngryBirds.Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.World;
import io.github.AngryBirds.Angry_Birds;
import io.github.AngryBirds.game_bodies.Birds.Bird;
import io.github.AngryBirds.game_bodies.Birds.Blue_Bird;
import io.github.AngryBirds.game_bodies.Birds.Red_Bird;
import io.github.AngryBirds.game_bodies.Birds.Yellow_Bird;
import io.github.AngryBirds.game_bodies.Targets.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import static io.github.AngryBirds.Screens.Level.pixel_to_meters;

public class Level_Selector implements Screen {
    protected SpriteBatch batch;
    protected Sprite background;
    protected Sprite level1;
    protected Sprite level2;
    protected Sprite level3;
    protected Sprite back;
    protected Sprite to_saved;
    private static final String Level1 = "../core/src/main/java/io/github/AngryBirds/Levels/Level 1/";
    private static final String Level2 = "../core/src/main/java/io/github/AngryBirds/Levels/Level 2/";
    private static final String Level3 = "../core/src/main/java/io/github/AngryBirds/Levels/Level 3/";
    Texture backgroundTexture = new Texture("level/levelselect.png");
    Texture level1Texture = new Texture("level/Level1.png");
    Texture level2Texture = new Texture("level/Level2.png");
    Texture level3Texture = new Texture("level/Level3.png");
    Texture backTexture = new Texture("level/nback.png");
    Texture to_savedTexture = new Texture("level/right.png");

    @Override
    public void show() {
        batch = new SpriteBatch();
        background = new Sprite(backgroundTexture);
        level1 = new Sprite(level1Texture);
        level2 = new Sprite(level2Texture);
        level3 = new Sprite(level3Texture);
        back = new Sprite(backTexture);
        to_saved = new Sprite(to_savedTexture);


        background.setSize(background.getWidth(), background.getHeight());

    }

    @Override
    public void render(float v) {
        batch.begin();
        background.draw(batch);
        level1.draw(batch);
        level2.draw(batch);
        level3.draw(batch);
        back.draw(batch);
        to_saved.draw(batch);

        batch.end();
        input();
    }

    @Override
    public void resize(int i, int i1) {
        batch = new SpriteBatch();
        back.setPosition(0, Gdx.graphics.getHeight()-backTexture.getHeight());
        level2.setPosition((float) Gdx.graphics.getWidth() /2-(float) level2Texture.getWidth()/2, 0);
        level1.setPosition(level2.getX()-level2.getWidth()*1.8f, 0);
        level3.setPosition(level2.getX()+level2.getWidth()*1.8f, 0);

        background.setPosition(0, 0);
        to_saved.setPosition(Gdx.graphics.getWidth()-to_saved.getWidth(), (float) Gdx.graphics.getHeight() /2);
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        batch.dispose();
        background.getTexture().dispose();
        level1.getTexture().dispose();
        level2.getTexture().dispose();
        level3.getTexture().dispose();
        back.getTexture().dispose();
        to_saved.getTexture().dispose();
    }

    public void input(){
        if(Gdx.input.isButtonJustPressed(Input.Buttons.LEFT)) {
            if (Angry_Birds.check(back)) {
                Angry_Birds.getInstance().setScreen(new Start_Screen());
            }
            else if(Angry_Birds.check(level1)) {
                Angry_Birds.getInstance().setScreen(new Level_Screen(Level1));
            }
            else if (Angry_Birds.check(level2)) {
                Angry_Birds.getInstance().setScreen(new Level_Screen(Level2));
            }
            else if (Angry_Birds.check(level3)) {
                Angry_Birds.getInstance().setScreen(new Level_Screen(Level3));
            }
            else if(Angry_Birds.check(to_saved)) {
                Angry_Birds.getInstance().setScreen(new Saved_Games());
            }
        }
    }
}
