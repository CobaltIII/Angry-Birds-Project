package io.github.AngryBirds.game_bodies;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.physics.box2d.*;

public abstract class game_body {
    protected int damage = 1;
    public int health = 1;
    protected int points;
    protected Body body;
    protected Sprite sprite;
    abstract public void setsize();
    abstract public void create_body(World world,float pixel_to_meters);

    public Body getBody(){
        return body;
    }
    public Sprite getSprite(){
        return sprite;
    }
    public void setposition(float pixel_to_meters){
        sprite.setPosition(body.getPosition().x*pixel_to_meters-sprite.getWidth()/2, body.getPosition().y*pixel_to_meters-sprite.getHeight()/2);
        sprite.setRotation(body.getAngle()* MathUtils.radiansToDegrees);
    }
    public int getpoints(){
        return points;
    }
    public void deal_damage(game_body attacker){
        this.health -= attacker.damage;
    }

    public int get_health(){
        return health;
    }


}

