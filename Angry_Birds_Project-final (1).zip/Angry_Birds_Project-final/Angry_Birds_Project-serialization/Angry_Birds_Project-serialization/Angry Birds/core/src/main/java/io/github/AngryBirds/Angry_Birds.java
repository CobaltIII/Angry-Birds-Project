package io.github.AngryBirds;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import io.github.AngryBirds.Screens.Start_Screen;
/** {@link com.badlogic.gdx.ApplicationListener} implementation shared by all platforms. */
public class Angry_Birds extends Game {
    static Angry_Birds game;
    private Angry_Birds() {

    }

    public static Angry_Birds getInstance(){
        if (game==null){
            game = new Angry_Birds();
        }
        return game;
    }

    @Override
    public void create() {
        setScreen(new Start_Screen());
    }

    public static boolean check(Sprite sprite) {
        if((Gdx.input.getX() >= sprite.getX())
            && (Gdx.input.getX() <= sprite.getX() + sprite.getWidth())
            && (Gdx.graphics.getHeight()-Gdx.input.getY() >= sprite.getY())
            && (Gdx.graphics.getHeight()-Gdx.input.getY() <= sprite.getY()+sprite.getHeight())){
            return true;
        }
        return false;
    }

}
