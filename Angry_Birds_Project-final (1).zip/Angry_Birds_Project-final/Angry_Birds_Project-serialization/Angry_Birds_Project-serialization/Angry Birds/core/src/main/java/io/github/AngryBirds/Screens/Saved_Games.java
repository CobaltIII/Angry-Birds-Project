package io.github.AngryBirds.Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import io.github.AngryBirds.Angry_Birds;

public class Saved_Games extends Level_Selector implements Screen {
    private Sprite to_new;
    private Sprite title;
    private static final String Level1 = "../core/src/main/java/io/github/AngryBirds/Levels/Level 1_s/";
    private static final String Level2 = "../core/src/main/java/io/github/AngryBirds/Levels/Level 2_s/";
    private static final String Level3 = "../core/src/main/java/io/github/AngryBirds/Levels/Level 3_s/";
    public Saved_Games() {
    }

    @Override
    public void show() {
        super.show();
        Texture to_newTexture = new Texture("level/left.png");
        Texture titleTexture = new Texture("level/Saved_Screen_Title2.png");
        to_new = new Sprite(to_newTexture);
        title = new Sprite(titleTexture);
        to_new.setPosition(0, Gdx.graphics.getHeight()/2);
        title.setPosition(Gdx.graphics.getWidth()/3.5f, Gdx.graphics.getHeight()-title.getHeight());
    }

    @Override
    public void render(float v) {
        super.render(v);
        batch.begin();
        to_new.draw(batch);
        title.draw(batch);
        batch.end();
    }

    @Override
    public void resize(int i, int i1) {
        super.resize(i, i1);
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        super.dispose();
        batch.dispose();
        to_new.getTexture().dispose();
        title.getTexture().dispose();
    }

    public void input(){
        if(Gdx.input.isButtonJustPressed(Input.Buttons.LEFT)) {
            if(Angry_Birds.check(level1)) {
                Angry_Birds.getInstance().setScreen(new Level_Screen(Level1));
            }
            else if (Angry_Birds.check(level2)) {
                Angry_Birds.getInstance().setScreen(new Level_Screen(Level2));
            }
            else if (Angry_Birds.check(level3)) {
                Angry_Birds.getInstance().setScreen(new Level_Screen(Level3));
            }
            else if(Angry_Birds.check(to_new)) {
                Angry_Birds.getInstance().setScreen(new Level_Selector());
            }
            else if(Angry_Birds.check(to_saved)){
                Angry_Birds.getInstance().setScreen(new Level_maker());
            }
            else if (Angry_Birds.check(back)){
                Angry_Birds.getInstance().setScreen(new Start_Screen());
            }
        }
    }

}
