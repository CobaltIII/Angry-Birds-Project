package io.github.AngryBirds.game_bodies.Birds;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import io.github.AngryBirds.Screens.Level;

import java.io.*;

public class Yellow_Bird extends Bird {
    Texture sprite_texture;

    public Yellow_Bird() {
        sprite_texture = new Texture("birds/Chuck-2.png");
        sprite = new Sprite(sprite_texture);
        setsize();
        this.health = 100;
        this.damage = 20;
        this.points = 100;
    }

    public Yellow_Bird(float x, float y) {
        this();
        sprite.setPosition(x, y);
    }

    public Yellow_Bird(int health, float body_x, float body_y, float angle, Vector2 linear_velocity, float angular_velocity, float pixel_to_meters, World world) {
        this();
        this.health = health;
        this.collided = collided;
        this.launched = launched;
        sprite.setPosition(body_x*pixel_to_meters-sprite.getWidth()/2, body_y*pixel_to_meters-sprite.getHeight()/2);
        sprite.setRotation(angle* MathUtils.radiansToDegrees);
        create_body(world,pixel_to_meters);
        body.setTransform(body_x,body_y,angle);
        body.setLinearVelocity(linear_velocity);
        body.setAngularVelocity(angular_velocity);
    }

    public void savable_save(Bird bird,String folderpath) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(folderpath+"Birds.txt" , true))) {
            // Format: health$body_x$body_y$angle$linear_velocity_x$linear_velocity_y$angular_velocity
            String data = "y" + bird.health + "$" + bird.getBody().getPosition().x + "$" + bird.getBody().getPosition().y + "$" + bird.getBody().getAngle() + "$"
                + bird.getBody().getLinearVelocity().x + "$" + bird.getBody().getLinearVelocity().y + "$"
                + bird.getBody().getAngularVelocity() + "$" + bird.collided + "$" + bird.launched;

            writer.write(data);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static float setterWidth(float x){
        if (x < 0){
            return 0.0f;
        }
        return x/20;
    }

    public static float setterOrigin(float t){
        return t/2;
    }

    public static Yellow_Bird readFromFile(String filename) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(filename));
        String line;
        Yellow_Bird bird = null;
        while ((line = reader.readLine()) != null) {
            if (line.startsWith("b")) {
                String[] parts = line.substring(1).split("\\$");
                int health = Integer.parseInt(parts[0]);
                float x = Float.parseFloat(parts[1]);
                float y = Float.parseFloat(parts[2]);
                float angle = Float.parseFloat(parts[3]);
                Vector2 linearVelocity = new Vector2(Float.parseFloat(parts[4]), Float.parseFloat(parts[5]));
                float angularVelocity = Float.parseFloat(parts[6]);
                boolean collided = Boolean.parseBoolean(parts[7]);
                boolean launched = Boolean.parseBoolean(parts[8]);

                bird = new Yellow_Bird(health, x, y, angle, linearVelocity, angularVelocity, 3.0f, null);
                bird.collided = collided;
                bird.launched = launched;
            }
        }
        reader.close();
        return bird;
    }

    @Override
    public void activateAbility(Level level) {
        body.setLinearVelocity(body.getLinearVelocity().x*100, body.getLinearVelocity().y);
    }

    @Override
    public void setsize() {
        sprite.setSize(sprite.getWidth()/20, sprite.getHeight()/20);
        sprite.setOrigin(sprite.getWidth()/2, sprite.getHeight()/2);
    }

    @Override
    public void create_body(World world,float pixel_to_meters) {
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyDef.BodyType.DynamicBody;

        CircleShape circle = new CircleShape();
        circle.setRadius(sprite.getWidth() /(2*pixel_to_meters));

        FixtureDef fd = new FixtureDef();
        fd.shape = circle;
        fd.density = 0.2f;
        fd.friction = 0.8f;
        fd.restitution = 0.4f;
        fd.filter.groupIndex = -1;

        body = world.createBody(bodyDef);
        body.createFixture(fd);
        body.setUserData(this);
        body.setAngularDamping(2);
    }
}
