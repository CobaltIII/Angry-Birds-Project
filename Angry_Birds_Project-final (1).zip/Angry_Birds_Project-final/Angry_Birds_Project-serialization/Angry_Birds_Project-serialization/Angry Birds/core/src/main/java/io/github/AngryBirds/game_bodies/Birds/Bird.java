package io.github.AngryBirds.game_bodies.Birds;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.physics.box2d.*;
import io.github.AngryBirds.Screens.Level;
import io.github.AngryBirds.game_bodies.game_body;

import java.io.IOException;

public abstract class Bird extends game_body {
    protected boolean collided = false;
    protected boolean launched = false;
    abstract public void activateAbility(Level level);
    public boolean get_launched(){
        return launched;
    }
    public boolean get_collided(){
        return collided;
    }
    public void set_launched(){
        this.launched = true;
    }
    public void set_collided(boolean collided){
        this.collided = collided;
    }

    public void savable_save(Bird bird,String folderpath) throws IOException {
        System.out.println("WRONG SAVED INVOKED");
    }
}
