package io.github.AngryBirds.Screens;

import com.badlogic.gdx.physics.box2d.*;
import io.github.AngryBirds.game_bodies.Birds.Bird;
import io.github.AngryBirds.game_bodies.Targets.Targets;
import io.github.AngryBirds.game_bodies.game_body;

import java.util.ArrayList;

public class collision_handler extends Level implements ContactListener {
    @Override
    public void beginContact(Contact contact) {
    }

    @Override
    public void endContact(Contact contact) {

    }

    @Override
    public void preSolve(Contact contact, Manifold manifold) {
        if ((contact.getFixtureA().getBody().getUserData() instanceof Bird || contact.getFixtureB().getBody().getUserData() instanceof Bird)) {
            Bird bird = contact.getFixtureA().getBody().getUserData() instanceof Bird ? (Bird) contact.getFixtureA().getBody().getUserData() : (Bird) contact.getFixtureB().getBody().getUserData();
            bird.set_collided(true);
            if((contact.getFixtureB().getBody().getUserData() instanceof Targets)|| (contact.getFixtureA().getBody().getUserData() instanceof Targets )) {
                game_body A = (game_body) contact.getFixtureA().getBody().getUserData();
                game_body B = (game_body) contact.getFixtureB().getBody().getUserData();
                System.out.println(A.get_health() + " " + B.get_health());
                A.deal_damage(B);
                B.deal_damage(A);
                System.out.println(A.get_health() + " " + B.get_health());
                if (B.get_health() <= 0) {
                    B.getBody().getFixtureList().get(0).getFilterData().groupIndex = -1;
                }
                if (A.get_health() <= 0) {
                    A.getBody().getFixtureList().get(0).getFilterData().groupIndex = -1;
                }
            }
        }

    }

    @Override
    public void postSolve(Contact contact, ContactImpulse contactImpulse) {

    }
}
