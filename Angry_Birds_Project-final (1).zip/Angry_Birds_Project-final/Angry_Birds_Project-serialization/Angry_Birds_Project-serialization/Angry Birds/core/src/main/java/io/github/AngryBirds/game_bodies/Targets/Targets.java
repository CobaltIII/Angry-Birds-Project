package io.github.AngryBirds.game_bodies.Targets;

import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.World;
import io.github.AngryBirds.game_bodies.game_body;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

abstract public class Targets extends game_body {
    protected int destroy(World world){
        world.destroyBody(body);
        sprite.getTexture().dispose();
        return points;
    }

    public void savable_save(float pixelToMeters,String folderpath) throws IOException{}
}
