package io.github.AngryBirds.Screens;

import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import io.github.AngryBirds.game_bodies.Birds.Bird;
import io.github.AngryBirds.game_bodies.Targets.Targets;
import io.github.AngryBirds.game_bodies.Targets.Pigs;
import io.github.AngryBirds.game_bodies.game_body;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

public class Level_Screen extends Level implements Screen {
    private int points = 0;
    private int max_points = 0;
    public Level_Screen() {
        super();
    }
    public Level_Screen(String folderpath){
        this.folderpath = folderpath;
    }

    private void addArrayListElements() {
        this.birds.addAll(save.BirdGetter(folderpath));
        this.targets.addAll(save.StructureGetter(folderpath));
        this.targets.addAll(save.PigGetter(folderpath));
        this.all_objects.addAll(targets);
        this.all_objects.addAll(birds);
    }


    private void set_max_points(){
        for (game_body g : all_objects){
            max_points += g.getpoints();
        }
    }

    @Override
    public void show() {
        super.show();
        addArrayListElements();
        set_max_points();
        world.setContactListener(new collision_handler());
    }

    @Override
    public void render(float v) {
        if (ended){
            world.step(0,0,0);
            draw_end(win,points,max_points);
            end_inputs();
        }
        else if (paused){
            world.step(0,0,0);
            draw_paused();
            try {
                pause_inputs();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        else {
            world.step(1/60f, 8,3);
            draw_game();
            if (!birds.isEmpty()) {
                Bird bird = birds.get(0);
                if (bird.get_launched() && Objects.equals(bird.getBody().getLinearVelocity(), new Vector2(0, 0))) {
                    world.destroyBody(bird.getBody());
                    birds.remove(bird);
                    all_objects.remove(bird);
                    if(!birds.isEmpty()&&!birds.get(0).get_launched())
                        set_bird_position();
                }
                normal_inputs();
            }
            destroy_bodies();
            game_end();
        }
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
        set_button_position();
        batch = new SpriteBatch();
        set_bird_position();
        set_target_position();
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        for (game_body g : all_objects){
            g.health = 0;
        }
        destroy_bodies();
        super.dispose();
    }

    private void delete_object(game_body game_body){
        if (game_body instanceof Targets){
            targets.remove(game_body);
            points += game_body.getpoints();
        }
        else if (game_body instanceof Bird){
            birds.remove(game_body);
            if (!birds.isEmpty() && !birds.get(0).get_launched())
                set_bird_position();
        }
        world.destroyBody(game_body.getBody());
        all_objects.remove(game_body);
    }

    private void destroy_bodies(){
        ArrayList<game_body> delete = new ArrayList<>();
        for (game_body game_body : all_objects) {
            if (game_body.get_health()<=0){
                delete.add(game_body);
            }
        }
        for (game_body game_body : delete) {
            delete_object(game_body);
        }
        delete.clear();
    }

    protected void game_end(){
        for (Targets t: targets){
            if (t instanceof Pigs){
                if (birds.isEmpty()) {
                    ended = true;
                    set_end(false,points,max_points);
                    return;
                }
                else {
                    return;
                }
            }
        }
        for (Bird bird : birds){
            points += bird.getpoints();
        }
        ended = true;
        set_end(true,points,max_points);
    }
}
