package io.github.AngryBirds.Screens;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.World;
import io.github.AngryBirds.game_bodies.Birds.Bird;
import io.github.AngryBirds.game_bodies.Birds.Blue_Bird;
import io.github.AngryBirds.game_bodies.Birds.Red_Bird;
import io.github.AngryBirds.game_bodies.Birds.Yellow_Bird;
import io.github.AngryBirds.game_bodies.Targets.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Serialize extends Level {
    private World world;
    private static Serialize instance;
    private Serialize (){
    }

    public void getWorld(World world) {
        this.world = world;
    }

    public static Serialize getInstance(){
        if (instance == null){
            instance = new Serialize();
        }
        return instance;
    }

    public ArrayList<Pigs> PigGetter(String folder_path){
        System.out.println("PigGetter");
        try (BufferedReader reader = new BufferedReader(new FileReader(folder_path+"Pigs.txt"))) {
            ArrayList<Pigs> pigs = new ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                Pigs pigg = readPigFromFile(line);
                pigs.add(pigg);
            }
            return pigs;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new ArrayList<>();
    }

    public ArrayList<Targets> StructureGetter(String folder_path){
        System.out.println("structureGetter");
        ArrayList<Targets> targets = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(folder_path+"Wood.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Wood wood = readWoodFromFile(line);
                targets.add(wood);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(folder_path+"Glass.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Glass glass = readGlassFromFile(line);
                targets.add(glass);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(folder_path+"Stone.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Stone stone = readStoneFromFile(line);
                targets.add(stone);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return targets;
    }

    public Glass readGlassFromFile(String line) {
        System.out.println("Glass");
        String[] parts = line.split("\\$");
        int health = Integer.parseInt(parts[0]);
        float bodyX = Float.parseFloat(parts[1]);
        float bodyY = Float.parseFloat(parts[2]);
        float angle = Float.parseFloat(parts[3]);
        Vector2 linearVelocity = new Vector2(Float.parseFloat(parts[4]), Float.parseFloat(parts[5]));
        float angularVelocity = Float.parseFloat(parts[6]);
        float pixelToMeters = Float.parseFloat(parts[7]);

        return new Glass(health, bodyX, bodyY, angle, linearVelocity, angularVelocity, pixelToMeters, this.world);
    }

    public Stone readStoneFromFile(String line) {
        System.out.println("stone");
        String[] parts = line.split("\\$");

        int health = Integer.parseInt(parts[0]);
        float bodyX = Float.parseFloat(parts[1]);
        float bodyY = Float.parseFloat(parts[2]);
        float angle = Float.parseFloat(parts[3]);
        Vector2 linearVelocity = new Vector2(Float.parseFloat(parts[4]), Float.parseFloat(parts[5]));
        float angularVelocity = Float.parseFloat(parts[6]);
        float pixelToMeters = Float.parseFloat(parts[7]);

        return new Stone(health, bodyX, bodyY, angle, linearVelocity, angularVelocity, pixelToMeters, this.world);
    }

    public Wood readWoodFromFile(String line) {
        System.out.println("wood");
        String[] parts = line.split("\\$");

        int health = Integer.parseInt(parts[0]);
        float bodyX = Float.parseFloat(parts[1]);
        float bodyY = Float.parseFloat(parts[2]);
        float angle = Float.parseFloat(parts[3]);
        Vector2 linearVelocity = new Vector2(Float.parseFloat(parts[4]), Float.parseFloat(parts[5]));
        float angularVelocity = Float.parseFloat(parts[6]);
        float pixelToMeters = Float.parseFloat(parts[7]);

        return new Wood(health, bodyX, bodyY, angle, linearVelocity, angularVelocity, pixelToMeters, this.world);
    }

    public Pigs readPigFromFile(String line) {
        System.out.println("pig");
        String[] parts = line.split("\\$");
        int health = Integer.parseInt(parts[0]);
        float bodyX = Float.parseFloat(parts[1]);
        float bodyY = Float.parseFloat(parts[2]);
        float angle = Float.parseFloat(parts[3]);
        Vector2 linearVelocity = new Vector2(Float.parseFloat(parts[4]), Float.parseFloat(parts[5]));
        float angularVelocity = Float.parseFloat(parts[6]);
        float pixelToMeters = Float.parseFloat(parts[7]);

        return new Pigs(health, bodyX, bodyY, angle, linearVelocity, angularVelocity, pixelToMeters, this.world);
    }

    public ArrayList<Bird> BirdGetter(String folder_path){
        System.out.println("Bird list");
        ArrayList<Bird> birds = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(folder_path+"Birds.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Bird birdd = readBirdFromLine(line);
                birds.add(birdd);
            }
            return birds;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return birds;
    }

    public Bird readBirdFromLine(String line) {
        System.out.println("Bird");
        Bird bird = null;
        if (line != null && !line.isEmpty()) {
            char type = line.charAt(0);
            String[] parts = line.substring(1).split("\\$");
            try {
                int health = Integer.parseInt(parts[0]);
                float x = Float.parseFloat(parts[1]);
                float y = Float.parseFloat(parts[2]);
                float angle = Float.parseFloat(parts[3]);
                Vector2 linearVelocity = new Vector2(Float.parseFloat(parts[4]), Float.parseFloat(parts[5]));
                float angularVelocity = Float.parseFloat(parts[6]);
                boolean collided = Boolean.parseBoolean(parts[7]);
                boolean launched = Boolean.parseBoolean(parts[8]);

                // Instantiate the specific bird based on the type
                switch (type) {
                    case 'b': // Blue_Bird
                        bird = new Blue_Bird(health, x, y, angle, linearVelocity, angularVelocity, pixel_to_meters, world);
                        break;
                    case 'y': // Yellow_Bird
                        bird = new Yellow_Bird(health, x, y, angle, linearVelocity, angularVelocity, pixel_to_meters, this.world);
                        break;
                    case 'r': // Red_Bird
                        bird = new Red_Bird(health, x, y, angle, linearVelocity, angularVelocity, pixel_to_meters, this.world);
                        break;
                    default:
                        throw new IllegalArgumentException("Unknown bird type: " + type);
                }

                // Set common properties
                if (bird != null) {
                    //bird.collided = collided;
                    //bird.launched = launched;
                }
            } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                System.err.println("Error parsing line: " + line);
                e.printStackTrace();
            }
        }
        return bird;
    }
}
