package io.github.AngryBirds.game_bodies.Targets;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Stone extends Targets {
    public Stone() {
        sprite = new Sprite(new Texture("blocks/Stone-1.png"));
        setsize();
        this.damage = 10;
        this.health = 100;
        this.points = 100;
    }


    public Stone(int health, float body_x, float body_y, float angle, Vector2 linear_velocity, float angular_velocity, float pixel_to_meters, World world) {
        this();
        this.health = health;
        sprite.setPosition(body_x*pixel_to_meters-sprite.getWidth()/2, body_y*pixel_to_meters-sprite.getHeight()/2);
        sprite.setRotation(angle* MathUtils.radiansToDegrees);
        create_body(world,pixel_to_meters);
        body.setTransform(body_x,body_y,angle);
        body.setLinearVelocity(linear_velocity);
        body.setAngularVelocity(angular_velocity);
    }

    public void writeStoneToFile(Stone stone, float pixelToMeters, String folderpath) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(folderpath+"Stone.txt" , true))) {
            // Format: health$body_x$body_y$angle$linear_velocity_x$linear_velocity_y$angular_velocity
            String data = stone.health + "$" +
                stone.body.getPosition().x + "$" +
                stone.body.getPosition().y + "$" +
                stone.body.getAngle() + "$" +
                stone.body.getLinearVelocity().x + "$" +
                stone.body.getLinearVelocity().y + "$" +
                stone.body.getAngularVelocity() + "$" +
                pixelToMeters;
            writer.write(data);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Stone readStoneFromFile(String line, World world) {
        String[] parts = line.split("\\$");

        int health = Integer.parseInt(parts[0]);
        float bodyX = Float.parseFloat(parts[1]);
        float bodyY = Float.parseFloat(parts[2]);
        float angle = Float.parseFloat(parts[3]);
        Vector2 linearVelocity = new Vector2(Float.parseFloat(parts[4]), Float.parseFloat(parts[5]));
        float angularVelocity = Float.parseFloat(parts[6]);
        float pixelToMeters = Float.parseFloat(parts[7]);

        return new Stone(health, bodyX, bodyY, angle, linearVelocity, angularVelocity, pixelToMeters, world);
    }

    @Override
    public void savable_save(float pixelToMeters,String folderpath) throws IOException {
        writeStoneToFile(this, pixelToMeters,folderpath);
    }

    public static float setterWidth(float x){
        if (x < 0){
            return 0.0f;
        }
        return x/20;
    }

    public static float setterOrigin(float t){
        return t/2;
    }
    @Override
    public void setsize() {
        sprite.setSize(sprite.getWidth() / 7.5f, sprite.getHeight() / 7.5f);
        sprite.setOrigin(sprite.getWidth() / 2, sprite.getHeight() / 2);
    }

    @Override
    public void create_body(World world, float pixel_to_meters) {
        pixel_to_meters *=2;
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyDef.BodyType.DynamicBody;
        bodyDef.position.set(10, 5);

        PolygonShape box = new PolygonShape();
        box.setAsBox(sprite.getWidth()/ pixel_to_meters, sprite.getHeight() / pixel_to_meters);

        FixtureDef fixd = new FixtureDef();
        fixd.shape = box;
        fixd.friction = 0.5f;
        fixd.restitution = 0.2f;
        fixd.density = 0.1f;

        body = world.createBody(bodyDef);
        body.createFixture(fixd);
        box.dispose();
        body.setLinearVelocity(0, 0);
        body.setUserData(this);
        body.setAngularDamping(2);
    }
}
