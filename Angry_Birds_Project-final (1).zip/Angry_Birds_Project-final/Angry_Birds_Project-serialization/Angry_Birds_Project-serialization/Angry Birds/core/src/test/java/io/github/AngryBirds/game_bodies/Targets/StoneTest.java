package io.github.AngryBirds.game_bodies.Targets;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Files;
import com.badlogic.gdx.files.FileHandle;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import com.badlogic.gdx.files.FileHandle;
import org.junit.Before;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
@RunWith(PowerMockRunner.class)
@PrepareForTest(FileHandle.class)
class StoneTest {

    @Mock
    FileHandle mockedFileHandle;

    @Before
    public void setUp() {
        // Mock FileHandle using PowerMock
        mockedFileHandle = PowerMockito.mock(FileHandle.class);
    }

    @Test
    void Test1() {
        assertThrows(NullPointerException.class, () -> {
            Stone birdd = new Stone();

            float x = birdd.setterWidth(30.0f);
            assertEquals(2.0, x);
        });

    }

    @Test
    void Test2() {
        assertThrows(NullPointerException.class, () -> {
            Stone birdd = new Stone();

            float x = birdd.setterWidth(0.0f);
            assertEquals(0.0f, x);
        });

    }

    @Test
    void Test3() {
        assertThrows(NullPointerException.class, () -> {
            Stone birdd = new Stone();

            float x = birdd.setterWidth(750.0f);
            assertEquals(50.0, x);
        });

    }

    @Test
    void Test4() {
        assertThrows(NullPointerException.class, () -> {
            Stone birdd = new Stone();

            float x = birdd.setterWidth(-40.0f);
            assertEquals(0.0, x);
        });

    }

    @Test
    void Test5() {
        assertThrows(NullPointerException.class, () -> {
            Stone birdd = new Stone();

            float x = birdd.setterWidth(-1.0f);
            assertEquals(0.0, x);
        });

    }

    @Test
    void Test6() {
        assertThrows(NullPointerException.class, () -> {
            Stone birdd = new Stone();

            float x = birdd.setterOrigin(40.0f);
            assertEquals(20.0, x);
        });

    }

    @Test
    void Test7() {
        assertThrows(NullPointerException.class, () -> {
            Stone birdd = new Stone();

            float x = birdd.setterOrigin(0.0f);
            assertEquals(0.0f, x);
        });

    }

    @Test
    void Test8() {
        assertThrows(NullPointerException.class, () -> {
            Stone birdd = new Stone();

            float x = birdd.setterOrigin(1000.0f);
            assertEquals(500.0, x);
        });

    }

    @Test
    void Test9() {
        assertThrows(NullPointerException.class, () -> {
            Stone birdd = new Stone();

            float x = birdd.setterOrigin(-40.0f);
            assertEquals(-20.0, x);
        });

    }

    @Test
    void Test10() {
        assertThrows(NullPointerException.class, () -> {
            Stone birdd = new Stone();

            float x = birdd.setterOrigin(-1.0f);
            assertEquals(-0.5, x);
        });

    }


}
